plugins { id("com.android.application"); kotlin("android") }
android { namespace="com.helsyvpn"; compileSdk=35
 defaultConfig { applicationId="com.helsyvpn"; minSdk=26; targetSdk=35; versionCode=1; versionName="1.0" }
 compileOptions { sourceCompatibility=JavaVersion.VERSION_17; targetCompatibility=JavaVersion.VERSION_17; coreLibraryDesugaringEnabled=true } }
dependencies { implementation("com.wireguard.android:tunnel:1.0.20260102"); coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.0.3") }