# helsyVpn
Clean Android Studio project for importing WireGuard .conf files and preparing a real WireGuard client.
Uses the official embeddable WireGuard Android tunnel library from Maven Central.
The previously posted PrivateKey must be considered compromised; generate a fresh config before use.
Build: Android Studio -> Build -> Build APK(s).
