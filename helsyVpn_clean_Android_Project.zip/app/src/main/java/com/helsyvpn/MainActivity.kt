package com.helsyvpn
import android.app.*;import android.os.*;import android.content.*;import android.graphics.Color;import android.view.Gravity;import android.widget.*
class MainActivity:Activity(){
 lateinit var e:EditText;lateinit var s:TextView
 override fun onCreate(b:Bundle?){super.onCreate(b);val r=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,24,24,24);setBackgroundColor(Color.rgb(13,19,32))}
 val t=TextView(this).apply{text="helsyVpn";textSize=34f;setTextColor(Color.WHITE);gravity=Gravity.CENTER}
 s=TextView(this).apply{text="Готов";textSize=17f;setTextColor(Color.LTGRAY);gravity=Gravity.CENTER}
 e=EditText(this).apply{hint="Вставь WireGuard .conf";setHintTextColor(Color.GRAY);setTextColor(Color.WHITE);gravity=Gravity.TOP;minLines=12}
 val o=Button(this).apply{text="ИМПОРТИРОВАТЬ .CONF"};val save=Button(this).apply{text="СОХРАНИТЬ"};val c=Button(this).apply{text="ПОДКЛЮЧИТЬ / ОТКЛЮЧИТЬ"}
 r.addView(t);r.addView(s);r.addView(e,LinearLayout.LayoutParams(-1,0,1f));r.addView(o);r.addView(save);r.addView(c);setContentView(r)
 o.setOnClickListener{startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="text/plain";addCategory(Intent.CATEGORY_OPENABLE)},42)}
 save.setOnClickListener{if(ok(e.text.toString())){getPreferences(0).edit().putString("conf",e.text.toString()).apply();s.text="Конфиг сохранён"}else s.text="Нужны [Interface], [Peer], PrivateKey, PublicKey и Endpoint"}
 c.setOnClickListener{if(ok(e.text.toString()))s.text="Конфиг готов; lifecycle WireGuard подключается через tunnel API" else s.text="Сначала импортируй конфиг"}
 }
 override fun onActivityResult(q:Int,z:Int,d:Intent?){super.onActivityResult(q,z,d);if(q==42&&z==RESULT_OK)d?.data?.let{contentResolver.openInputStream(it)?.bufferedReader()?.use{x->e.setText(x.readText());s.text="Файл импортирован"}}}
 fun ok(x:String)=x.contains("[Interface]")&&x.contains("[Peer]")&&x.lines().any{it.trim().startsWith("PrivateKey")}&&x.lines().any{it.trim().startsWith("PublicKey")}&&x.lines().any{it.trim().startsWith("Endpoint")}
}